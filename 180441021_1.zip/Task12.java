/**
　* 基本課題1.2　メインクラス
 * @author 180441021 太田迪
 */
import java.util.Random;
import java.util.Scanner;
public class Task12 {
	public static void main(String[] arg) {
		System.out.print("じゃんけん\n");
		Janken();
	}
	public static int Janken() {
		
		Random rnd = new Random();
		Scanner scanner= new Scanner(System.in);
		int i;
		while(true) {
			System.out.print("(0:グー,　1:チョキ,　2:パー)>");
			i = scanner.nextInt();
			if(i>=0&&i<3)break;
		}
		int r = rnd.nextInt() % 3;
		int judge =(i - r) % 3;
		System.out.print("ポン！　");
		System.out.print("あなた");
		judge_hand(i);
		System.out.print(",相手");
		judge_hand(r);
		if(judge==0) {
			System.out.println("あいこ");
			return Janken();
		}
		else if(judge==1) {
			System.out.println("勝ち");
			return 0;
		}
		else if(judge==2) {
			System.out.println("負け");
			return 0;
		}
		else return 0;
	}
	public static void judge_hand(int x) {
		while(x<0)x+=3;
		if(x==0)System.out.print("「グー」");
		else if(x==1)System.out.print("「チョキ」");
		else if(x==2)System.out.print("「パー」");
	}
}
