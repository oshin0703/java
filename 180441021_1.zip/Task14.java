/**
　 *　基本課題1.4 メインクラス
 * @author 180441021 太田迪
 */
import java.util.Scanner;
public class Task14 {
	public static void main(String[] args){
		System.out.print("> java Task14 ");
		Scanner scanner=new Scanner(System.in);
		String check = scanner.nextLine();
		
		if(isNumber(check)) {
			System.out.println("コマンドライン引数に数値が指定されていません");
		}
		else {
			int value = Integer.parseInt(check);
			int primenum=search(value);
			if(value<=0) {
				System.out.println("コマンドライン引数に不正な値が指定されましたプログラムを終了します.");
			}
			else if(value<=2) {
				System.out.println(value+"未満の素数はありません.");
			}
			else {
				System.out.println(value+"未満の最大素数は"+primenum);
			}
		}
	}
	

	public static int search(int value) {
		boolean[] judge =new boolean[value];
		int prime=1;
		for(int i=2;i<value;i++)judge[i]=false;
		for(int i=2;i<value;i++) {
			if(judge[i]==false) {
				for(int j=i*2;j<value;j+=i) {
					judge[j]=true;
				}	
				prime=i;
			}
		}
		return prime;
	}
	
	public static boolean isNumber(String val) {
		try {
			Integer.parseInt(val);
			return false;
		} catch (NumberFormatException nfex) {
			return true;
		}
	}
}