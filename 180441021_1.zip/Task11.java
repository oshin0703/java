/**
　*　基本課題1.1 メインクラス
 * @author 180441021 太田迪
 */

import java.util.Scanner;

public class Task11{
    public static void main(String[] arg){
        System.out.print("ファイルサイズ(GB) : ");
    	Scanner scanner =new Scanner(System.in);
        int filesize = scanner.nextInt();   
        System.out.print("スループット(Mbps) : ");
        double throughput = scanner.nextDouble();
        System.out.print("予想ダウンロード時間:");
        getDownloadTime(filesize,throughput);
    
	 }
    public static  void getDownloadTime(int filesize,double throughput) {
    	double time;
        time = (filesize * 1024 * 8) / throughput;
        int h;
        h = (int)time / 3600;
        time = time - h * 3600;
        int m;
        m = (int)time / 60;
        time = time - m * 60;
        int s = (int)time;
        if(h==0){
            if(m==0){
                System.out.println(s+"時間");
            }
            else{
                System.out.println(m+"分"+s+"秒");
            }
        }
        else{
            if(m==0){
                System.out.println(h+"時間"+s+"秒");
            }
            else{
                System.out.println(h+"時間"+m+"分"+s+"秒");
            }
        }
    }
}

