import java.util.Scanner;
public class Task32 {
	public static void main(String[] args) {
	
		Triangle t = new Triangle();
		t.setTriangle(args);
		t.show();
		System.out.print("三角形の移動量を入力して下さい　[dx dy]: ");
		double dx,dy;
		Scanner scanner = new Scanner(System.in); 
		dx=scanner.nextDouble();
		dy=scanner.nextDouble();
		t.translate(dx,dy);
		t.show();
	}
}
