/** 
 * 基本課題3.1　点クラス
 * @author 180441021  太田迪
 */
public class Point {
	private double x;
	private double y;
	
	
	public void Point() {
		setLocation(0,0);
	}
	
	public void Point(double x,double y) {
		setLocation(x,y);
	}
	
	public double getX() {
		return this.x;
	}
	
	public double getY() {
		return this.y;
	}
	
	public void setX(double x) {
		this.x=x;
	}
	
	public void setY(double y) {
		this.y=y;
	}
	
	public void setLocation(double x,double y) {
		setX(x);
		setY(y);
	}
	
	public void move(double x,double y) {
		this.x=x;
		this.y=y;
	}
	
	public void translate(double dx,double dy) {
		this.x+=dx;
		this.y+=dy;
	}
	
	public String toString() {
		return "("+getX()+","+getY()+")";
	}
	
	public double getDistance() {
		return getDistance(0,0);
	}
	
	public double getDistance(double x,double y) {
		double tmp;
		tmp=Math.pow(x-getX(), 2)+Math.pow(y-getY(), 2);
		
		return Math.sqrt(tmp);
	}
	
	public double getDistance(Point p) {
		return getDistance(p.getX(),p.getY());
	}
	
	public double getDistance(Point p1,Point p2) {
		double tmp;
		tmp=Math.pow(p1.getX()-p2.getX(), 2)+Math.pow(p1.getY()-p2.getY(), 2);
		return Math.sqrt(tmp);
	}
}
