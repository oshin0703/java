
public class Triangle {
	private Point A = new Point();
	private Point B = new Point();
	private Point C = new Point();
	
	public void setTriangle(String[] args){
		this.A.Point(Double.parseDouble(args[0]),Double.parseDouble(args[1]));
		this.B.Point(Double.parseDouble(args[2]),Double.parseDouble(args[3]));
		this.C.Point(Double.parseDouble(args[4]),Double.parseDouble(args[5]));
	}
	
	public void translate(double dx,double dy) {
		this.A.translate(dx, dy);
		this.B.translate(dx, dy);
		this.C.translate(dx, dy);
	}
	
	public void show() {
		System.out.println("三角形の頂点座標:A"+this.A.toString()+", B"+this.B.toString()+", C"+this.C.toString());
	}
}
