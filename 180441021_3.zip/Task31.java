/** 
 * 基本課題3.1　動作確認クラス
 * @author 180441021  太田迪
 */
import java.util.Scanner;

public class Task31 {
	public static void main(String[] args) {
		double x1,y1,x2,y2,dx,dy;
		Scanner scanner = new Scanner(System.in);
		
		Point p1 = new Point();
		Point p2 = new Point();
		
		p1.Point();
		System.out.println("点P1("+p1.getX()+","+p1.getY()+")を生成しました");
		
		System.out.print("点P2の座標を入力してください　[x,y]: ");
		x2=scanner.nextDouble();
		y2=scanner.nextDouble();
		scanner.nextLine();
		p2.Point(x2,y2);
		System.out.println("点P2"+p2.toString()+"を生成しました");
		
		System.out.println("P1とP2間の距離d1="+p1.getDistance(p2.getX(),p2.getY()));
		
		System.out.print("P1の移動先座標を入力してください　[x,y]: ");
		x1=scanner.nextDouble();
		y1=scanner.nextDouble();
		scanner.nextLine();
		p1.move(x1, y1);
		System.out.println("移動後の点P1の座標 =("+p1.toString());
		System.out.println("P1とP2間の距離d2 = "+p1.getDistance(p2));
		System.out.print("点P2の移動量を入力してください　[dx dy]: ");
		dx=scanner.nextDouble();
		dy=scanner.nextDouble();
		
		p2.translate(dx, dy);
		System.out.println("移動後の点P2の座標　="+p2.toString());
		System.out.println("P1とP2間の距離d3 = "+p1.getDistance(p1,p2));
		System.out.println("原点とP2間の距離d4 = "+p2.getDistance());
	}
}
