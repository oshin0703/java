/** 
 * 基本課題3.3　動作確認クラス
 * @author 180441021  太田迪
 */
import java.util.Scanner;
public class Task33 {
	public static void main(String[] args) {
		System.out.print("演算回数を入力>");
		Scanner scanner = new Scanner(System.in);
		long count=scanner.nextLong();	
		
		
		PiCalculater p = new PiCalculater();
		p.Pi(count);
		System.out.print("演算回数 "+p.getCount()+" で円周率を演算開始...");
		p.work();
		System.out.println("演算終了");
		System.out.println("処理時間="+p.getTime()+"ms");
		System.out.println("演算結果="+p.getResult());
		System.out.println("誤差="+p.getDifference());
	}
}