package jp.ac.meijo_u.id180441021.anbayasiroulette;

public class MyData {
    static String off = "残念！";
    static String ok ="まぁまぁ";
    static String good ="あたり";
    static String best = "大当たり";

    static String[] commentArray = {off,ok,off,good,off,best,ok,off,good,ok,off,good,off,good,off,
            best,ok,best,good,ok,off,good,off,good,off,best,ok,good,off,ok};

    static Integer[] numberArray={5,8,5,10,5,14,9,5,10,8,5,10,4,12,5,20,8,15,12,8,4,10,5,10,5,15,7,14,5,8};

    static Integer[] additionArray={3,2,3,1,4,1,1,5,2,2,3,1,4,2,3,0,2,0,2,2,4,2,3,1,3,0,3,1,5,2};
}
