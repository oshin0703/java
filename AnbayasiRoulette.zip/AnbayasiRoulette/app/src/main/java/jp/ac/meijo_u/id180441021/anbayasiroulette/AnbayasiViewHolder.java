package jp.ac.meijo_u.id180441021.anbayasiroulette;



import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class AnbayasiViewHolder extends RecyclerView.ViewHolder {
    public AnbayasiViewHolder(@NonNull View itemView) {
        super(itemView);
    }
}
