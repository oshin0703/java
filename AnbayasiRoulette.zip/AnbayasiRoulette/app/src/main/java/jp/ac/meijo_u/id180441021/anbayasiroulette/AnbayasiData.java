package jp.ac.meijo_u.id180441021.anbayasiroulette;

public class AnbayasiData {
    //あんばやしの本数
    private int number;
    //おまけの本数
    private int addition;
    //コメント内容
    private String comment;

    //コントラスタ
    public AnbayasiData(int number,int addition,String comment){
        this.number = number;
        this.addition = addition;
        this.comment = comment;
    }

    public int getNumber(){
        return number;
    }

    public int getAddition(){
        return addition;
    }

    public String getComment(){
        return comment;
    }
}
