/**
 * 	3次元空間上の点を扱う基本課題4.1
 */
/** 
 * 基本課題4.1　動作確認クラス
 * @author 180441021  太田迪
 */
import java.util.Scanner;
public class Task41 {

	public static void main(String[] args) {
		// 	原点に点P1を生成
		Point3D p1 = new Point3D();
		System.out.println("点P1" + p1.toString() + "を生成しました．");
		
		// 	キーボードで指定した座標に点P2を生成
		System.out.print("点P2の座標を入力して下さい[x y z]: ");
		Scanner scanner = new Scanner(System.in);
		double x= scanner.nextDouble();
		double y= scanner.nextDouble();
		double z= scanner.nextDouble();
		scanner.nextLine();
		Point3D p2 = new Point3D(x,y,z);
		System.out.println("点P2" + p2.toString() + "を生成しました．");

		// 	キーボードで点P2の移動量を入力して移動させる
		System.out.print("点P2の移動量を入力して下さい[dx dy dz]: ");
		double dx= scanner.nextDouble();
		double dy= scanner.nextDouble();
		double dz= scanner.nextDouble();
		p2.translate(dx, dy, dz);
		System.out.println("移動後の点P2の座標 = " + p2.toString());
	}

}
