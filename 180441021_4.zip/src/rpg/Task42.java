/** 
 * 基本課題4.2　動作確認クラス
 * @author 180441021  太田迪
 */
package rpg;
import rpg.monsters.*;
public class Task42 {
	public static void main(String[] args) {
		Goblin g1 = new Goblin('A');
		Warwolf w1 = new Warwolf('A');
		Deathbat d1 = new Deathbat('A');
		Deathbat d2 = new Deathbat('B');
		g1.attack();
		w1.attack();
		d1.attack();
		d2.attack();
		g1.run();
		w1.run();
		d1.run();
		d2.run();
	}
}
