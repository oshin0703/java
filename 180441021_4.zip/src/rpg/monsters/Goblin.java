/** 
 * 基本課題4.2　ゴブリンクラス
 * @author 180441021  太田迪
 */
package rpg.monsters;

public class Goblin extends Monster {
	public Goblin(char suffix){
		this.hp=10;
		this.mp=100;
		this.name="ゴブリン";
		this.suffix=suffix;
	}
	
	public void attack() {
		System.out.println(toString()+"はナイフで斬りつけた!");
	}
	
	public void run() {
		System.out.println(toString()+"はトコトコ走って逃げた!");
	}
}
