/** 
 * 基本課題4.2　抽象クラス
 * @author 180441021  太田迪
 */
package rpg.monsters;

public abstract class Monster {
	protected int hp;
	protected int mp;
	protected String name;
	protected char suffix;
	
	public void setHp(int hp){
		this.hp=hp;
	}
	
	public void setMp(int mp) {
		this.mp=mp;
	}
	
	public void setName(String name) {
		this.name=name;
	}
	
	public void setSuffix(char suffix) {
		this.suffix=suffix;
	}
	
	public double getHp() {
		return this.hp;
	}
	
	public double getMp() {
		return this.mp;
	}
	
	public String name() {
		return this.name;
	}
	
	public char suffix(){
		return this.suffix;
	}
	public abstract void attack();
	
	public abstract void run();
	
	public String toString() {
		return this.name+this.suffix; 
	}
}

