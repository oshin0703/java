/** 
 * 基本課題4.2　デスバットクラス
 * @author 180441021  太田迪
 */
package rpg.monsters;

public class Deathbat extends Monster {
	public Deathbat(char suffix){
		this.hp=10;
		this.mp=100;
		this.name="デスバット";
		this.suffix=suffix;
	}
	
	public void attack() {
		System.out.println(toString()+"は突っついた!");
	}
	
	public void run() {
		System.out.println(toString()+"はバサバサ飛んで逃げた!");
	}
}
