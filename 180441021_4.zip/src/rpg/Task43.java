/** 
 * 基本課題4.3　動作確認クラス
 * @author 180441021  太田迪
 */
// 		パッケージに所属させる（消さないこと！）
package rpg;

// 	必要なクラスをインポート
import rpg.monsters.*;
import java.util.Random;
/**
 * 基本課題4.3（雛形）
 */
public class Task43 {

	public static void main(String[] args) {
		//	 発生させるモンスターの数を2〜5の範囲で生成する
		Random rand = new Random();
		int num = rand.nextInt(3) + 2;
		// 	生成するモンスターを格納する配列を作成
		Monster[] m = new Monster[num];
		
		// 	モンスターをランダムに生成
		char g_suffix ='A';
		char w_suffix ='A';
		char d_suffix ='A';
		for(int i=0; i<num; i++) {
			int type = rand.nextInt(3);
			if(type==0) {
				m[i] = new Goblin(g_suffix);
				g_suffix++;
			}
			if(type==1) {
				m[i] = new Warwolf(w_suffix);
				w_suffix++;
			}
			if(type==2) {
				m[i] = new Deathbat(d_suffix);
				d_suffix++;
			}
		}

		// 	生成したモンスターを表示
		showMonsters(m);
		
		// 	モンスターがランダムに行動
		int count = 0;
		while(m[count]!=null) {
			Boolean f = rand.nextBoolean();
			if(f) {
				m[count].attack();
			}
			else {
				m[count].run();
				m[count]=null;
				if(count < num - 1) {
					count++;
				}
			}
		}
		// 	全てのモンスターが逃げ出したら表示
		System.out.println("\nモンスターは全て逃げ出した！");
	}

	/**
	 * モンスターの一覧を表示するクラスメソッド
	 * @param XXX	モンスターを管理している配列（型と引き数名を設定すること）
	 */
	private static void showMonsters(Monster[] m) {
		int i;
		for(i=0;i<m.length - 1;i++) {
			
			 System.out.print(m[i].toString()+" ,");
		}
		System.out.println(m[i].toString()+"が現れた！\n");
	}
}
