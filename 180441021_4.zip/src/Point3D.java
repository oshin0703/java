/** 
 * 基本課題4.1　3D点クラス
 * @author 180441021  太田迪
 */
public class Point3D extends Point{
	private double z;
	
	public Point3D() {
		super();
		setZ(0.0);
	}
	
	public Point3D(double x,double y,double z) {
		super(x,y);
		setZ(z);
	}
	
	public double getZ() {
		return this.z;
	}
	
	public void setZ(double z) {
		this.z=z;
	}
	
	public void translate(double dx,double dy,double dz) {
		this.x += dx;
		this.y += dy;
		this.z += dz;
	}
	
	@Override
	public String toString() {
		return "(" + this.x + ", " + this.y +", " + this.z + ")";
	}
	
}
