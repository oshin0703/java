/**
 * Task8_PC　チャットサーバースレッドクラス
 * @author 180441021 太田迪
 */
package ac.jp.meijo_u.id180441021.task8_pc;
import java.io.*;
import java.net.*;
import java.util.*;
public class ChatServerThread extends Thread{
	private ArrayList<ChatServerThread> account;
	private Socket socket;
	private String name;
	public ChatServerThread(Socket socket,ArrayList<ChatServerThread> account) {
		this.socket=socket;
		this.account = account;
		InputStream is = null;
		DataInputStream dis = null;
		OutputStream os = null;
		DataOutputStream dos = null;
		String name;
		try {
			is = socket.getInputStream();
			dis = new DataInputStream(is);
			this.name = dis.readUTF();
		    name = this.name+" ";
			
		    //	自分以外のクライアントに入室を通知
			for(ChatServerThread thread:account) {
				if(!thread.getname().equals(this.name)) {
					System.out.println(this.name);
					os = thread.getsocket().getOutputStream();
					dos = new DataOutputStream(os);
					dos.writeUTF(this.name+"が入室しました!");
					dos.flush();
					
					name +=(" "+thread.getname());
				}
			}
			System.out.println(this.name+"が入室しました!");
			
			//	現在チャットに参加中の人を通知
			os = this.socket.getOutputStream();
			dos = new DataOutputStream(os);
			dos.writeUTF(name+"が参加しています");
			dos.flush();
		
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	//	クライアントから受け取った名前を出力
	public String getname() {
		return this.name;
	}
	
	//	クライアントから受け取ったソケットを出力
	public Socket getsocket() {
		return this.socket;
	}
	
	@Override
	public void run() {

		InputStream is = null;
		DataInputStream dis= null;
		OutputStream os = null;
		DataOutputStream dos = null; 
		String message = "";
		String[] Message;
		try {	
			while(true) {
				//	クライアントからのメッセージを受信
				is = this.socket.getInputStream();
				dis = new DataInputStream(is);
				message = dis.readUTF();
				
				
				//	クライアントが切断した場合Message[0]+"	が退室しました!"とほかの人に通知し、切断する
				Message = message.split(">");
				if(Message[1].equals("Bye!")) {
					this.socket.close();
					account.remove(account.indexOf(this));
					for(ChatServerThread thread:account) {
						os = thread.getsocket().getOutputStream();
						dos = new DataOutputStream(os);
						dos.writeUTF(Message[0]+"が退室しました!");
						dos.flush();
					}
					System.out.println(Message[0]+"が退室しました!");
					break;
				}
				//	すべてのクライアントにメッセージを送信
				else {
					for(ChatServerThread thread:account) {
						os = thread.getsocket().getOutputStream();
						dos = new DataOutputStream(os);
						dos.writeUTF(message);
						dos.flush();
					}
					System.out.println(message);
				}
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		} 
	}
}
