/**
 * Task8_PC　チャットクライアントコントローラークラス
 * @author 180441021 太田迪
 */
package ac.jp.meijo_u.id180441021.task8_pc;
import java.io.*;
import java.net.*;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;
public class ChatClientController {
	@FXML private Button connect;
	@FXML private Button save;
	@FXML private Button send;
	@FXML private Button cut;
	@FXML private TextField ip;
	@FXML private TextField port;
	@FXML private TextField name;
	@FXML private TextArea chat;
	@FXML private TextField message;
	private ConnectTask connectTask;
	private SendTask sendTask;
	private Thread connectThread;
	private Thread sendThread;
		
	@FXML protected void handleButtonconnectAction(ActionEvent event){
		//	接続に必要なIPアドレス、ポート番号、名前の読み込み
		String server = ip.getText().toString();
		String portNumber = port.getText().toString();
		String Name = name.getText().toString();

		//	サーバーと接続する
		connectTask = new ConnectTask(server,portNumber,Name);
		
		//	メッセージを受け取るスレッドを作成
		this.connectThread = new Thread(connectTask);
		chat.textProperty().bind(connectTask.messageProperty());
		connectThread.setDaemon(true);
		connectThread.start();
	}
	
	@FXML protected void handleButtonsaveAction(ActionEvent event){
		FileWriter fw = null;
		BufferedWriter bw = null;
		String fp = "log.txt";
		String text = chat.getText().toString();
		try {
			fw = new FileWriter(fp);	//	 ファイル出力文字ストリーム
			bw = new BufferedWriter(fw);	//	 出力用バッファ
			// 	引数で指定した文字列を出力用バッファに書き込む
			bw.write(text);
			//	 出力用バッファの内容をファイルへ書き出す
			bw.flush();
			
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle("読み込み成功");
			alert.setHeaderText(null);
			alert.setContentText(fp + "に保存しました.");
			alert.showAndWait();
		}catch (IOException e) {
			Alert alert = new Alert(AlertType.ERROR);
			alert.setHeaderText("保存失敗");
			alert.setContentText(e.getMessage());
			alert.showAndWait();
		} finally {
		
			if (bw != null) {
				try {
					bw.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	@FXML protected void handleButtonsendAction(ActionEvent event) {
		//	メッセージを読み込む
		String Message = message.getText().toString();
		Socket socket = connectTask.getSocket();
		String Name = name.getText().toString();
		
		//	メッセージを送信するスレッドの作成
		sendTask = new SendTask(socket,Message,Name);
		sendThread = new Thread(sendTask);
		sendThread.setDaemon(true);
		sendThread.start();
	}
	
	@FXML protected void handleButtoncutAction(ActionEvent event) {
		
		//	サーバーに切断を送信
		String message = "Bye!";
		Socket socket = connectTask.getSocket();
		String Name = name.getText().toString();
		sendTask = new SendTask(socket,message,Name);
		Thread thread = new Thread(sendTask);
		thread.setDaemon(true);
		thread.start();
		//	受信するタスクを閉じる
		chat.textProperty().unbind();
		connectTask.cancel();
		
		//	使用したチャットを初期化する
		chat.setText("");
		
	}
}
