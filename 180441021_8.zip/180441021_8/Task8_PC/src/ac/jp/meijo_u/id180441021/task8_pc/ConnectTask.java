/**
 * 基本課題6.3 ネットクロッククラス
 * @author 180441021 太田　迪
 */
package ac.jp.meijo_u.id180441021.task8_pc;

/**
 * Task8_PC　チャットクライアント接続クラス
 * @author 180441021 太田迪
 */
import java.io.*;
import java.net.*;
import javafx.concurrent.*;

public class ConnectTask extends Task<Void>{
	private String ip;
	private int port;
	private String name;
	private String chat = "";
	private Socket socket = null;
	
	//	コントラスタの初期化
	public ConnectTask(String ip,String port,String name){
		this.ip=ip;
		this.port = Integer.parseInt(port);
		this.name = name;
		//	ソケットの接続
		try {
			this.socket = new Socket();
			// 	指定されたホスト名（IPアドレス）とポート番号でサーバに接続する
			this.socket.connect(new InetSocketAddress(this.ip,this.port));
		}catch(Exception e) {}
	}
	
	//	繋いだソケットを出力するメソッド
	public Socket getSocket() {
		return this.socket;
	}
	
	@Override
	protected Void call() throws Exception{
		InputStream is = null;
		DataInputStream dis = null;
		OutputStream os = null;
		DataOutputStream dos = null;

		try {
			//	 接続されたソケットの入力ストリームを取得し，データ入力ストリームを連結
			os = this.socket.getOutputStream();
			dos = new DataOutputStream(os);
			dos.writeUTF(this.name);
			dos.flush();
			
			while(true) {
				is = this.socket.getInputStream();
				dis = new DataInputStream(is);
				// 	データの受信
				String message = dis.readUTF();
				//	メッセージをチャットに追加
				this.chat += (message+"\r\n");
				
				//	 チャットにアップデート
				updateMessage(this.chat);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if(this.socket!=null) {
				try {
					this.socket.close();
				}catch(Exception e) {
					e.printStackTrace();
				}
			}
		}
		return null;
	}
}
