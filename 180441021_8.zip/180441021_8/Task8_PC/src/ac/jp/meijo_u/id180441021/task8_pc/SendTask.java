/**
 * Task8_PC　チャットクライアント送信クラス
 * @author 180441021 太田迪
 */
package ac.jp.meijo_u.id180441021.task8_pc;

import java.io.*;
import java.net.*;
import javafx.concurrent.*;

public class SendTask extends Task<Void>{
	private Socket socket;
	String message;
	String name;
	//	コントラスタの初期化
	public SendTask(Socket socket,String message,String name){
		this.socket = socket;
		this.message = message;
		this.name = name;
	}
	@Override
	protected Void call() throws Exception{
		OutputStream os = null;
		DataOutputStream dos = null;
		
		try {
			//	 ソケットからメッセージをサーバーに送信
			os = this.socket.getOutputStream();
			dos = new DataOutputStream(os);
			dos.writeUTF(this.name+">"+this.message);
			dos.flush();

		} catch (Exception e) {
			e.printStackTrace();
		} 
		return null;
	}
}
