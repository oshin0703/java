/**
 * Task8_PC　チャットサーバーメインクラス
 * @author 180441021 太田迪
 */
package ac.jp.meijo_u.id180441021.task8_pc;
import java.net.*;
import java.util.*;
public class ChatServer{
	private static final int MAX_CONNECTION = 100;
	private static ServerSocket serverSocket;
	private static ArrayList<ChatServerThread> account = new ArrayList<>();
	
	
	public static void main(String[] args) {
		System.out.println("サーバーを起動しました");
		int port = Integer.parseInt(args[0]);
		
		Socket socket = null;
		try {
			//	クライアントと接続処理
			serverSocket = new ServerSocket();
			serverSocket.setReuseAddress(true);
			serverSocket.bind(new InetSocketAddress(port),MAX_CONNECTION);
			while(true) {
				//	サーバースレッドの生成
				socket = serverSocket.accept();
				ChatServerThread thread = new ChatServerThread(socket,account);
				thread.start();
				account.add(thread);
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			if(socket!=null) {
				try {
					socket.close();
				}catch(Exception e) {
					e.printStackTrace();
				}
			}
		}
		
	}
	
}
