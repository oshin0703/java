package jp.ac.meijo_u.id180441021.task8_android;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.widget.*;
import java.io.*;


public class MainActivity extends AppCompatActivity {
    ProgressDialog Dialog = null;
    private EditText  editServerIP,editServerPort,editName,editChat,editMessage;
    private TextView IP_label,port_label,name_label,chat_text,message_text;
    private Button buttonConnect,buttonSave,buttonSend,buttonCut;

    private ConnectTask connectTask;
    private SendTask sendTask;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
        //GUIコンポーネントの取得
        editServerIP = (EditText) findViewById(R.id.editServerIP);
        editServerPort = (EditText) findViewById(R.id.editServerPort);
        editName = (EditText) findViewById(R.id.editName);
        editChat = (EditText) findViewById(R.id.editChat);
        editMessage = (EditText) findViewById(R.id.editMessage);
        IP_label = (TextView) findViewById(R.id.IP_label);
        port_label = (TextView) findViewById(R.id.port_label);
        name_label = (TextView) findViewById(R.id.name_label);
        chat_text = (TextView) findViewById(R.id.chat_text);
        message_text = (TextView) findViewById(R.id.message_text);
        buttonConnect = (Button) findViewById(R.id.buttonConnect);
        buttonSave = (Button) findViewById(R.id.buttonSave);
        buttonSend = (Button) findViewById(R.id.buttonSend);
        buttonCut = (Button) findViewById(R.id.buttonCut);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void handleButtonConnectAction(View view){
        try {
            //サーバIPアドレスの取得
            String IP = editServerIP.getText().toString();
            //サーバポート番号を取得
            String port = editServerPort.getText().toString();
            //名前を取得
            String name = editName.getText().toString();

            int Port = Integer.parseInt(port);

            //サーバと通信するバックグラウンドタスクを生成・開始
            connectTask = new ConnectTask(IP, Port, name, this);
            connectTask.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);

            showToast("接続開始");
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    /**
     *
     * @param view
     */
    public void handleButtonSaveAction(View view){
        FileWriter fw = null;
        BufferedWriter bw = null;
        String fp = "log.txt";
        String text = editChat.getText().toString();
        try{
            fw = new FileWriter(fp);
            bw = new BufferedWriter(fw);
            bw.write(text);
            bw.flush();
            showToast("保存完了");
        }catch(IOException e){
            e.printStackTrace();
        }finally{
            if(bw!=null){
                try{
                    bw.close();
                }catch(IOException e){
                    e.printStackTrace();
                }
            }
        }
    }

    public void handleButtonSendAction(View view){
        //送信依頼
        sendTask = new SendTask(editName.getText().toString(),editMessage.getText().toString(),this);
        sendTask.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
    }

    /**
     * サーバーとの送受信を切断するメソッド
     * @param view
     */
    public void handleButtonCutAction(View view){
        //切断依頼
        sendTask = new SendTask(editName.getText().toString(),"Bye!",this);
        sendTask.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
        connectTask.cancel(true);
        editChat.setText("");
        setButtonEnabled(true);
    }

    /**
     * 接続ボタンを使用可能かを決めるメソッド
     * @param enabled
     */
    public void setButtonEnabled(boolean enabled){
        buttonConnect.setEnabled(enabled);
    }

    /**
     * トーストを表示するメソッド
     * @param message
     */
    public void showToast(String message){
        Toast.makeText(this,message,Toast.LENGTH_SHORT).show();
    }

    /**
     * チャット欄にチャット内容を追加するメソッド
     * @param chat
     */
    public void setChat(String chat){
        editChat.setText(chat);
    }

    /**
     * ConnectTaskを取得するメソッド
     * @return this.connectTask
     */
    public ConnectTask getTask(){
        return this.connectTask;
    }
}
