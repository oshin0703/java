package jp.ac.meijo_u.id180441021.task8_android;

import android.os.AsyncTask;
import java.io.*;
import java.net.*;

public class SendTask extends AsyncTask<Void,String,Boolean> {
    /** サーバーIPアドレス*/
    private String serverIP;
    /** サーバーポート番号*/
    private int serverPort;
    /** 名前*/
    private String name;
    /** チャット*/
    private String message="";
    /** 接続しているソケット　*/
    private Socket socket = null;

    private MainActivity mainActivity;

    public String getmessage(){
        return this.message;
    }

    /*public SendTask(String serverIP,int serverPort,String name,String message,MainActivity mainActivity){
        this.serverIP = serverIP;
        this.serverPort = serverPort;
        this.name = name;
        this.message=message;
        this.mainActivity=mainActivity;
    }*/
    public SendTask(String name,String message,MainActivity mainActivity){
        this.name=name;
        this.message=message;
        this.mainActivity=mainActivity;
    }

    @Override
    protected Boolean doInBackground(Void... params) {
        OutputStream os ;
        DataOutputStream dos;
        try{
            //接続したソケットを共有
           this.socket = mainActivity.getTask().getSocket();
            //サーバーに接続する名前を送信
            os = this.socket.getOutputStream();
            dos = new DataOutputStream(os);
            dos.writeUTF(this.name+">"+this.message);
            dos.flush();
        }catch(IOException e){
            e.printStackTrace();
        }
        return true;
    }
    /**
     * バックグラウンドタスク完了時に呼び出されるメソッド
     * @params result    コールバックメソッドへ渡すBoolean値(可変長引数)
     */
    @Override
    protected void onPostExecute(Boolean result){
        mainActivity.showToast("送信完了");
    }

    /**
     * バックグラウンドタスク実行時にpublishProgress()メソッドにより呼び出されるメソッド
     * @params values       コールバックメソッドへ渡す文字列(可変長引数)
     */
    @Override
    protected void onProgressUpdate(String... values){
        mainActivity.setChat(values[0]);
    }
}
