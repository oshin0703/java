import java.net.*;
import java.io.*;
import java.util.*;

public class Task53Client {
	public static void main(String[] args) {
		String server = args[0];
		
		int port = Integer.parseInt(args[1]);
		
		Socket socket = null;
		try {
			System.out.println("サーバ["+server+"]に接続中...");
			
			socket= new Socket();
			socket.connect(new InetSocketAddress(server,port));
			
			System.out.println("接続完了\n");
			System.out.println("演算回数を入力>");
			Scanner scanner = new Scanner(System.in);
			long cal = scanner.nextLong();
			
			System.out.println("演算回数を送信中...\n");
			OutputStream os = socket.getOutputStream();
			DataOutputStream dos = new DataOutputStream(os);
			dos.writeLong(cal); 
			dos.flush();
			
			InputStream is = socket.getInputStream();
			DataInputStream dis = new DataInputStream(is);
			String message = dis.readUTF();
			System.out.println(message);
			
			long Time = dis.readLong();
			double result = dis.readDouble();
			double difference = dis.readDouble();
			System.out.println("処理時間"+Time+"ms　演算結果="+result+"(誤差="+difference+")");
				
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			if(socket!=null){
				try {
					socket.close();
				}catch(IOException e) {}
			}
		}
	}
}
