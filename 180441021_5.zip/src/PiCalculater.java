
public class PiCalculater {
	long count;
	double result;
	double difference;
	long time;
	
	public void Pi(long count) {
		setCount(count);
		setResult(0);
		setDifference(0);
		setTime(0);
	}

	
	public void setCount(long count) {
		this.count=count;
	}
	
	public long getCount() {
		return this.count;
	}
	
	public void setResult(double result) {
		this.result=result;
	}
	
	public double getResult() {
		return this.result;
	}
	
	public void setDifference(double difference){
		this.difference=difference;
	}
	
	public double getDifference() {
		return this.difference;
	}
	
	public void setTime(long time) {
		this.time=time;
	}
	public long getTime() {
		return this.time;
	}
	
	public void calculateResult(long count) {
		long n=0;
		for(long i=0;i<count;i++) {
			double x=Math.random();
			double y=Math.random();
			if(Math.pow(x, 2)+Math.pow(y, 2) <= 1) {
				n++;
			}
		}
		this.result=4.0*n/count;
	}
	
	public void calculateDifference(){
		this.difference=this.result-Math.PI;
	}
	
	public void work() {
		long startTime=System.currentTimeMillis();
		calculateResult(getCount());
		calculateDifference();
		long stopTime=System.currentTimeMillis();
		this.time=stopTime-startTime;
	}
}

