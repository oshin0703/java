import java.io.*;
public class Task52 {
	public static void main(String[] args) {
		FileInputStream fis = null;
		BufferedInputStream bis = null;
		DataInputStream dis = null;
		final byte[] PNG = {(byte)0x89,0x50,0x4E,0x47,0x0D,0x0A,0x1A,0x0A};
		try {
			fis = new FileInputStream(args[0]);
			bis = new BufferedInputStream(fis);
			dis = new DataInputStream(bis);
			int width;
			int height;
			byte[] IHDR = new byte[8];
			
			for(int i=0;i<8;i++) {
				IHDR[i] = dis.readByte();
				if(IHDR[i]!=PNG[i]) {
					throw new Exception();
				}
			}
			
			dis.readLong();
			width=dis.readInt();
			height=dis.readInt();
			System.out.println("Width = "+width+" pixel, Height = "+height+" pixel");
			}catch(IOException e){
			e.printStackTrace();
			System.exit(1);
		}catch(Exception e) {
			System.out.println(args[0]+"はPNGファイルではありません");
		}
		
	}
}
