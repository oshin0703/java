
import java.io.*;
import java.util.*;
import java.net.*;


public class Task53Server {
	private static final int MAX_CONNECTION = 100;
	private static ServerSocket serverSocket;
	private static Date date;
	
	public static void main(String[] args) {
		
		//コマンドライン引数からポート番号を取得
		int port = Integer.parseInt(args[0]);
		
		Socket socket = null;
		try {
			serverSocket = new ServerSocket();
			serverSocket.setReuseAddress(true);
			
			serverSocket.bind(new InetSocketAddress(port),MAX_CONNECTION);
			System.out.println("ポート"+port+"番をリッスン中...");
			while(true) {
				socket = serverSocket.accept();
				
				InputStream is = socket.getInputStream();
				DataInputStream dis = new DataInputStream(is);
	
				InetAddress address = socket.getInetAddress();
				int clientPort = socket.getPort();
				System.out.println("クライアント[/" +address+ ":" +clientPort+ "]が接続しました。");
				
				long count = dis.readLong();
				
				System.out.println("クライアントへ演算を開始することを通知します。");
				OutputStream os = socket.getOutputStream();
				DataOutputStream dos = new DataOutputStream(os);
				String hostName = socket.getLocalAddress().getHostName();
				dos.writeUTF("サーバ" + hostName + "が演算を開始しました。");
				dos.flush();
				
				PiCalculater p = new PiCalculater();
				p.Pi(count);
				System.out.println("演算回数" +count + "で演算を開始...");
				p.work();
				System.out.print("演算終了\n");
				
				//演算結果のメッセージを送信
				double result = p.getResult();
				double difference = p.getDifference();
				double time = p.getTime();
				System.out.println("クライアントへ演算結果[" + time + "ms" + result+ "]を返信します。");
				
				dos.writeUTF("サーバが演算を終了しました。\n");
				dos.flush();
				
				dos.writeDouble(time);
				dos.writeDouble(result);
				dos.writeDouble(difference);
				dos.flush();
				socket.close();
				
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
}
