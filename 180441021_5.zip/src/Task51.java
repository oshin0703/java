import java.io.*;
public class Task51 {
	public static void main(String[] args) {
		FileReader fr = null;
		BufferedReader br = null;	

		int year = Integer.parseInt(args[1]);
		int month = Integer.parseInt(args[2]);
		
		int[] days = {31,28,31,30,31,30,31,31,30,31,30,31};
		if(year%4==0 && (year % 100 != 0 || year % 400 ==0))days[1]=29;
		
		WeatherData[] wd = new WeatherData[days[month-1]];
		try {
			fr = new FileReader(args[0]);	// 	ファイル入力文字ストリーム
			br = new BufferedReader(fr);	// 	入力用バッファ
			String str;
			str = br.readLine();
			int num=0;
				while ((str = br.readLine()) != null) {
					String[] data = str.split("[/,]");	
					
					if(Integer.parseInt(data[0])==year&&Integer.parseInt(data[1])==month) {
						
						
						int date = Integer.parseInt(data[2]);
						double averageTemperature = Double.parseDouble(data[3]);
						double maxTemperature = Double.parseDouble(data[4]);
						double minTemperature = Double.parseDouble(data[5]);
						double rainfall = Double.parseDouble(data[6]);
						double hoursOfDaylight = Double.parseDouble(data[7]);
							
						 wd[num] = new WeatherData(year,month,date,averageTemperature,maxTemperature,minTemperature,rainfall,hoursOfDaylight); 
						 num++;
					 }
				
			
			}if(wd==null) throw new Exception();		
		
		} catch (FileNotFoundException e) {
			System.out.println("ファイル" + args[0] + "が見つかりません．");
			System.exit(1);
		} catch (IOException e) {
			e.printStackTrace();
		}catch(Exception e) {
			System.out.println("指定された"+args[1]+"年"+args[2]+"月のデータがありません");
			e.printStackTrace();
		}finally {
			/*
			 * BufferedReaderストリームをクローズ
			 * （連結されているFileReaderストリームも同時にクローズされる）
			 */
			if (fr != null) {
				try {
					fr.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			FileWriter fw = null;
			BufferedWriter bw = null;
			try {
				String[] filename;
				filename=args[0].split(".csv");
				fw = new FileWriter(filename[0]+"_"+args[1]+"-"+args[2]+".csv");
				bw = new BufferedWriter(fw);
				bw.write("年月日,平均気温(℃),最高気温(℃),最低気温(℃),降水量の合計(mm),日照時間(時間)");
				bw.newLine();
				for(int i=0;i<wd.length;i++) {
					bw.write(wd[i].toString());
					bw.newLine();
				}
				bw.flush();
				
				WeatherData.showMonthlySummary();
			}catch(IOException e) {
				e.printStackTrace();
				System.exit(1);
			}finally {

			if (bw != null) {
					try {
						bw.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}
		}
	}
}
