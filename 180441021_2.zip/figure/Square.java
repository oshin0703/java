package figure;
public class Square {
	public double width;
	public double height;
	
	public void setWidth(double width) {
		this.width=width;
	}
	
	public double getWidth() {
		return this.width;
	}
	
	public void setHeight(double height){
		this.height=height;
	}
	
	public double getHeight() {
		return this.height;
	}
	
	public double getArea() {
		return this.height*this.width;
	}
	
	public double getAround() {
		return 2*(this.height+this.width);
	}
	
	public String toString() {
		return "Square[width="+this.width+",height="+this.height+"]";
		}
	
	
}
