package figure;

public class Circle {
	public double radius;
	
	public void setRadius(double radius) {
		this.radius=radius;
	}
	
	public double getRadius() {
		return 	this.radius;
	}
	
	public double getArea() {
		return Math.pow(this.radius,2)*Math.PI;
	}
	
	public double getAround() {
		return 2*radius*Math.PI;
	}
	
	public String toString() {
		return "Circle[radius"+this.radius+"]";
	}
}
