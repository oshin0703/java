package figure;
public class Triangle {
	public double width;
	public double height;
	
	public void setWidth(double width) {
		this.width=width;
	}
	
	public double getWidth() {
		return this.width;
	}
	
	public void setHeight(double height){
		this.height=height;
	}
	
	public double getHeight() {
		return this.height;
	}
	
	public double getArea() {
		return this.height*this.width/2.0;
	}
	
	public double getAround() {
		return this.height+this.width+Math.sqrt(Math.pow(this.height,2)+Math.pow(this.width,2));
	}
	
	public String toString() {
		return "Triangle[width="+this.width+",height="+this.height+"]";
	}
	
}
