
public class SmartCard {
	public final int INITIAL_BALANCE = 1000;
	public String name;
	public String PhoneNumber;
	public long balance;
	
	public String getName(){
		return this.name;
	}
	
	public void setName(String name) {
		this.name=name;
	}
	
	public String getPhoneNumber() {
		return this.PhoneNumber;
	}
	
	public void setPhoneNumber(String PhoneNumber) {
		this.PhoneNumber=PhoneNumber;
	}
	
	public long getBalance() {
		return this.balance;
	}
	
	public void setInitial_Balance() {
		this.balance = this.INITIAL_BALANCE; 
	}
	
	public void charge(int amount){
		this.balance += amount;
	}
	
	public boolean pay(int amount) {
		if(this.balance < amount) return false;
		else {
			this.balance-=amount;
			return true;
		}
	}
	
	public String toString() {
		return "SmartCard[name="+this.name+",PhoneNumber="+this.PhoneNumber+",balance="+this.balance+"]";
	}
}
