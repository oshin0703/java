package id180441021;
public class Point {
	private int x;
	private int y;
	
	public int getX() {
		return this.x;
	}
	
	public void setX(int x) {
		this.x=x;
	}
	
	public int getY() {
		return this.y;
	}
	
	public void setY(int y) {
		this.y=y;
	}
	
	public String toString() {
		return "("+this.x+","+this.y+")";
	}
	
	public void setXY(int x,int y) {
		this.x=x;
		this.y=y;
	}
	
	public int[] getXY() {
		int[] tmp=new int[2];
		tmp[0]=this.x;
		tmp[1]=this.y;
		return tmp;
	}
	
	public double getDistance(int x,int y) {
		double tmp;
		tmp=Math.pow(x-this.x, 2)+Math.pow(y-this.y, 2);
		
		return Math.sqrt(tmp);
	}
	
	public double getDistance() {
		return getDistance(0,0);
	}
	
}
