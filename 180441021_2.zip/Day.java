
public class Day {
	public int year;
	public int month;
	public int date;
	public int getYear()
	{
		return this.year;
	}
	
	public void setYear(int year) {
		this.year=year;
	}
	
	public int getMonth() {
		return this.month;
	}
	
	void setMonth(int month) {
		this.month=month;
	}
	
	public int getDate() {
		return this.date;
	}
	
	public void setDate(int date) {
		this.date=date;
	}
	
	public String getDayOfWeek() {
		int check;
		int date=this.date;
		int month=this.month;
		int year=this.year;

		String[] day= {"日曜日","月曜日","火曜日","水曜日","木曜日","金曜日","土曜日"};
		
		check=(year+year/4-year/100+year/400+(13*month+8)/5+date)%7;
		for(int i=0;i<day.length;i++) {
			if(i==check) {
				return day[i];
			}
		}
		return null;
	}
	public String toString() {
		String message = String.format("%d年%d月%d日",this.year,this.month,this.date);
		return message;
	}
}
