/** 
 * 基本課題2.3　動作確認クラス
 * @author 180441021 太田迪
 */
import java.util.Scanner;
public class Task23 {
	public static void main(String[] args) {
		/* 1. キーボードで入力した氏名と電話番号を用いてスマートカードを作成 */
		System.out.println("スマートカードを作成します．");
		Scanner scanner = new Scanner(System.in);
		SmartCard sc = new SmartCard();
		System.out.println("所有者名を入力してください>");
		String name=scanner.nextLine();
		System.out.println("電話番号を入力してください>");
		String PhoneNumber=scanner.nextLine();
		
		sc.setName(name);
		sc.setPhoneNumber(PhoneNumber);
		sc.setInitial_Balance();
		System.out.println("スマートカードを作成しました．\n");

		/* 2. カード残高を表示する */
		System.out.println("スマートカードの情報を表示します．");
		System.out.println("所有者氏名:"+sc.getName());
		System.out.println("電話番号\t:"+sc.getPhoneNumber());
		System.out.println("残高\t:"+sc.getBalance());
		/* 3. キーボードで入力した金額を支払おうとするが残高不足のため，チャージして支払う */
		System.out.print("支払金額を入力してください> ");
		int money=scanner.nextInt();
		while(!sc.pay(money)) {
			System.out.println("残高が不足しているため支払いできません.");
			System.out.println("チャージ金額を入力してください>");
			scanner.nextLine();
			int charge=scanner.nextInt();
			sc.charge(charge);
		}
		System.out.println(money+"円を支払いました.\n");
		
		/* 4. カード残高を表示する */
		System.out.println("スマートカードの情報を表示します．");
		System.out.println("所有者氏名:"+sc.getName());
		System.out.println("電話番号\t:"+sc.getPhoneNumber());
		System.out.println("残高\t:"+sc.getBalance());
	}

}