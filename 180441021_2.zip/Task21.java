import java.util.Scanner;
public class Task21 {
	public static void main(String[] args) {
		Day day = new Day();
		System.out.print("年月日を入力してください>");
		Scanner scanner= new Scanner(System.in);
		day.setYear(scanner.nextInt());
		day.setMonth(scanner.nextInt());
		day.setDate(scanner.nextInt());
		System.out.println(day.toString()+"は"+day.getDayOfWeek());
	}
}
