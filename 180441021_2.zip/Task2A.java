import figure.Circle;
import figure.Square;
import figure.Triangle;

public class Task2A {
	public static void main(String[] args) {
		Circle C = new Circle();
		Square S = new Square();
		Triangle T =new Triangle();
		
		double S_width=Double.parseDouble(args[0]);
		double S_height=Double.parseDouble(args[1]);
		double T_width=Double.parseDouble(args[2]);
		double T_height=Double.parseDouble(args[3]);
		double radius=Double.parseDouble(args[4]);
		
		S.setWidth(S_width);
		S.setHeight(S_height);
		T.setWidth(T_width);
		T.setHeight(T_height);
		C.setRadius(radius);
		
		System.out.println("四角形の幅と高さ="+S.getWidth()+" "+S.getHeight());
		System.out.println("三角形の底辺と高さ="+T.getWidth()+" "+T.getHeight());
		System.out.println("円の半径="+C.getRadius());
		
		System.out.println("四角形\t:面積 = "+S.getArea()+",周囲の長さ = "+S.getAround());
		System.out.println("三角形\t:面積 = "+T.getArea()+",周囲の長さ = "+T.getAround());
		System.out.println("円\t:面積 = "+C.getArea()+",周囲の長さ = "+C.getAround());
		
	}
}
