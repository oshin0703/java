/** 
 * 基本課題2.2　動作確認クラス
 * @author 180441021  太田迪
 */
import id180441021.Point;
import java.util.Scanner;
public class Task22 {

	/**
	 * メインメソッド
	 * @param args	X座標とY座標
	 */
	public static void main(String[] args) {
		// 	点P1を作成してコマンドライン引数で指定した座標を設定
		Point p = new Point(); 
		Scanner scanner = new Scanner(System.in);
		
		int[] p1=new int[2];
		p1[0]=Integer.parseInt(args[0]);
		p1[1]=Integer.parseInt(args[1]);
		p.setXY(p1[0],p1[1]);
		
		System.out.println("点　p1"+p.toString()+"を生成しました.");
		
		// 	点P1に関する情報の表示
		System.out.println("X座標="+p.getX()+",Y座標="+p.getY());

		// 	 原点とP1間の距離を表示
		System.out.println("原点からp1までの距離="+p.getDistance());

		// 	点P2を作成してキーボードで指定した座標を設定
		System.out.print("P2の座標を入力してください> ");
		int[] p2 =new int[2];
		p2[0]=scanner.nextInt();
		p2[1]=scanner.nextInt();
		// P1-P2間の距離を表示
		System.out.println("P1-P2間の距離="+p.getDistance(p2[0],p2[1]));
	}

}