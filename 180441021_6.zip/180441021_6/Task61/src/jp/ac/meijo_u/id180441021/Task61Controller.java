/**
 * 基本課題6.1 コントローラークラス
 * @author 180441021 太田　迪
 */
package jp.ac.meijo_u.id180441021;

import java.io.*;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;


public class Task61Controller {
	@FXML private TextField filename;
	@FXML private TextArea filetext;
	@FXML private Button Load;
	@FXML private Button Save;
	
	@FXML protected void loadwork(ActionEvent event) {
		FileReader fr = null;
		BufferedReader br = null;
		String file = filename.getText();
		try {
			fr = new FileReader(file);	
			br = new BufferedReader(fr);	
			String text = "";
			String str;
			while ((str = br.readLine()) != null)
				text += str + "\r\n";
			
			filetext.setText(text);
			
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle("読み込み成功");
			alert.setHeaderText(null);
			alert.setContentText(file+"に読み込みました.");
			alert.showAndWait();
		} catch (IOException e) {
			Alert alert = new Alert(AlertType.ERROR);
			alert.setHeaderText(null);
			alert.setContentText(e.getMessage());
			alert.showAndWait();
		} finally {
			/*
			 * BufferedReaderストリームをクローズ
			 * （連結されているFileReaderストリームも同時にクローズされる）
			 */
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	@FXML protected void savework(ActionEvent event) {
		FileWriter fw = null;
		BufferedWriter bw = null;
		String fp = filename.getText();
		String text = filetext.getText();
		try {
			fw = new FileWriter(fp);	//	 ファイル出力文字ストリーム
			bw = new BufferedWriter(fw);	//	 出力用バッファ
			// 	引数で指定した文字列を出力用バッファに書き込む
			bw.write(text);
			//	 出力用バッファの内容をファイルへ書き出す
			bw.flush();
			
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle("読み込み成功");
			alert.setHeaderText(null);
			alert.setContentText(fp + "に保存しました.");
			alert.showAndWait();
		}catch (IOException e) {
			Alert alert = new Alert(AlertType.ERROR);
			alert.setHeaderText("保存失敗");
			alert.setContentText(e.getMessage());
			alert.showAndWait();
		} finally {
			/*
			 * BufferedWriterストリームをクローズ
			 * （連結されているFileWriterストリームも同時にクローズされる）
			 */
			if (bw != null) {
				try {
					bw.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
}
