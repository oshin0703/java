/**
 * 基本課題6.2 ストップウォッチクラス
 * @author 180441021 太田　迪
 */
package jp.ac.meijo_u.id180441021;

import javafx.concurrent.*;

public class StopWatchTask extends Task<Void>{
	private int min;
	private int sec;
	private int ms;
	
	public StopWatchTask() {
		this.min = 0;
		this.sec = 0;
		this.ms = 0;
	}
	
	@Override
	protected Void call() throws Exception{
		int count = 0;
		while(true) {
			if (isCancelled())
				break;
			
			min = count / 6000;
			sec = (count - min*6000) / 100;
			ms = count - min*6000 - sec*100;
			
			updateMessage(String.format("%02d:%02d:%02d",min,sec,ms));
			Thread.sleep(10);
			count++;
		}
		return null;
		
	}
}
