/**
 * 基本課題6.2 コントローラークラス
 * @author 180441021 太田　迪
 */
package jp.ac.meijo_u.id180441021;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;

public class Task62Controller {
	@FXML private Button start;
	@FXML private Button stop;
	@FXML private Label time;
	
	private StopWatchTask task;
	
	@FXML protected void handleButtonStartAction(ActionEvent event) {
		task = new StopWatchTask();
		time.textProperty().bind(task.messageProperty());
		
		Thread thread = new Thread(task);
		thread.setDaemon(true);
		thread.start();
	}
	
	@FXML protected void handleButtonStopAction(ActionEvent event) {
		task.cancel();
		time.textProperty().unbind();
	}
}
