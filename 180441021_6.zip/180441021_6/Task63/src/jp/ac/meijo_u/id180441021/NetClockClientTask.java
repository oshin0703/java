/**
 * 基本課題6.3 ネットクロッククラス
 * @author 180441021 太田　迪
 */
package jp.ac.meijo_u.id180441021;

import java.io.*;
import java.net.*;
import javafx.concurrent.*;

public class NetClockClientTask extends Task<Void>{
	private String ip;
	private String port;
	
	NetClockClientTask(String ip,String port){
		this.ip=ip;
		this.port=port;
	}
	
	@Override
	protected Void call() throws Exception{
		//	 コマンドライン引数から接続先サーバのホスト名またはIPアドレスを取得
		String server = this.ip;
		// 	コマンドライン引数からポート番号を取得
		int port = Integer.parseInt(this.port);

		Socket socket = null;
		try {
			// ソケットを作成
			socket = new Socket();
			// 	指定されたホスト名（IPアドレス）とポート番号でサーバに接続する
			socket.connect(new InetSocketAddress(server, port));
			//	 接続されたソケットの入力ストリームを取得し，データ入力ストリームを連結
			InputStream is = socket.getInputStream();
			DataInputStream dis = new DataInputStream(is);
			
			// データの受信
			String message = dis.readUTF();
			// 受信したデータを表示
			updateMessage(message);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// ソケットをクローズする
			if (socket != null) {
				try {
					socket.close();
				} catch (IOException e) {}
			}
		}
		return null;
	}
}
