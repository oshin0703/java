/**
 * 基本課題6.3 メインクラス
 * @author 180441021 太田　迪
 */
package jp.ac.meijo_u.id180441021;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;

public class Task63Controller {
	@FXML private Button connect;
	@FXML private TextField ip;
	@FXML private TextField port;
	@FXML private TextArea result;
	private NetClockClientTask task;
	
	@FXML protected void handleButtonconnectAction(ActionEvent event){
		String server = ip.getText();
		String portNumber = port.getText();
		
		task = new NetClockClientTask(server,portNumber);
		result.textProperty().bind(task.messageProperty());
		Thread thread = new Thread(task);
		thread.setDaemon(true);
		thread.start();
	}
}
